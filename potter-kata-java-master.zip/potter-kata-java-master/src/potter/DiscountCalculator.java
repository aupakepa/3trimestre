package potter;

public class DiscountCalculator {

	public double calculate(int[] books) {
		return 0.0;
	}
}
