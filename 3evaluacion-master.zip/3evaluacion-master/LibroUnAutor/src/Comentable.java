
public interface Comentable {

	public void comentar(String texto);
	public String comentario();
}
