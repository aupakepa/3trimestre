import java.util.Arrays;

public class GestionLibroAutor {
	public static void main(String[] args) {
		Libro[] libros = null;
		Autor[] autores = null;
		String  nombre = "", titulo = "";
		Comentable comentarios[] = new Comentable[100];

		Integer opcion, cuantosLibros,posLibro=0,posAutor=0,numComent=0;

		libros = new Libro[10];
		autores = new Autor[10];

		posAutor=creaAutores(autores,posAutor,numComent,comentarios);
		posLibro=creaLibros(autores,posLibro,libros,numComent,comentarios);
		
		do {
			
			libros = ampliaLibros(libros, posLibro);// amplia los libros si es necesario
			autores = ampliaAutores(autores, posAutor);// amplia los autores si es necesario
			opcion = menu();//muestra menu y lee la opci�n

			switch (opcion) {
			case 1: // creamos un autor guard�ndolo en la posici�n posAutor
				posAutor= creaAutor( autores, posAutor);					
				break;
			case 2: // creamos un libro guard�ndolo en la posici�n posLibro
				if(posAutor==0){
					Leer.mostrarEnPantalla("Debe crear antes al menos un autor");
				} else{
					posLibro=crearLibros( posLibro, libros, autores);					
				}
				break;
			case 3: // modificar autor 				
				if(posAutor==0){
					Leer.mostrarEnPantalla("No hay autores en la lista");
				}else {
					listarAutores(autores);
					nombre = Leer.pedirCadena("Nombre del autor a modificar (* para terminar)");
					if (!nombre.equals("*")) {
						modificarAutor(autores, nombre);
					}
				}
				break;
			case 4: // modificar libro
				if(posLibro==0){
					Leer.mostrarEnPantalla("No hay libros en la lista");
				}else {
					listarLibros(libros);
					titulo = Leer.pedirCadena("Titulo del libro a modificar (* para terminar)");
					if (!titulo.equals("*")) {
						modificarLibro(libros, titulo, autores);
					}
				}
				break;
			case 5: // listar autores
				if(posAutor==0){
					Leer.mostrarEnPantalla("No hay autores en la lista");
				}else {
					listarAutores(autores);
				}

				break;
			case 6: // listar libros
				if(posLibro==0){
					Leer.mostrarEnPantalla("No hay libros en la lista");
				}else {
					listarLibros(libros);
				}
				break;
			case 7: // Comentar libros y autores
				Integer opc=0;
				opc=Leer.pedirEntero("Que quieres modifica? \n1.- Libros \n2.- Autores", "1|2");
				switch (opc) {
				case 1:
					mostrarLibros(comentarios);
					Integer indice = Leer.pedirEntero("introduzca el ID del Autor");
					if (comentarios[indice] instanceof Libro) {
						comentarios[indice].comentar(Leer.pedirCadena("introduzca rese�a"));
					}
					else{
						Leer.mostrarEnPantalla("Si quieres lo cambio pero es un Autor");
					}
					break;

				case 2:
					mostrarAutores(comentarios);
					indice = Leer.pedirEntero("introduzca el ID del Autor");
					if (comentarios[indice] instanceof Autor) {
						comentarios[indice].comentar(Leer.pedirCadena("introduzca la Biografia del autor"));
					}
					else{
						Leer.mostrarEnPantalla("Si quieres lo cambio pero es un Libro");
					}
					break;
				
				default:
					break;
				}
			case 8:
				opc=Leer.pedirEntero("Que quieres ordenar? \n 1.- Libros \n 2. Autores\n 3. Comentarios", "[1-3]");
				switch (opc) {
				case 1:
					Leer.mostrarEnPantalla(Arrays.toString(libros));
					Arrays.sort(libros, 0, Libro.getContador());
					Leer.mostrarEnPantalla(Arrays.toString(libros));
					break;

				case 2:
					Leer.mostrarEnPantalla(Arrays.toString(autores));
					Arrays.sort(autores, 0, Autor.getSiguiente());
					Leer.mostrarEnPantalla(Arrays.toString(autores));
					break;
				case 3:
					Leer.mostrarEnPantalla(Arrays.toString(comentarios));
					Arrays.sort(comentarios, 0, Autor.getSiguiente()+ Libro.getContador()-1);
					Leer.mostrarEnPantalla(Arrays.toString(comentarios));
					break;	

				default:
					break;
				}
			default:
				break;
				}
		} while (opcion != 0);

	}

	private static void mostrarAutores(Comentable comentarios []) {
		for (int i = 0; i < comentarios.length; i++) {
			if (comentarios[i] != null && comentarios[i] instanceof Autor) {
			Leer.mostrarEnPantalla(i+".- " + ((Autor)comentarios[i]).getNombre());
		}
			else if (comentarios[i] != null && !(comentarios[i] instanceof Autor)) {
				Leer.mostrarEnPantalla("no has introducido un id de Autor correcto");
			}
		}
}
	private static void mostrarLibros(Comentable comentarios []) {
		for (int i = 0; i < comentarios.length; i++) {
			if (comentarios[i] != null && comentarios[i] instanceof Libro) {
			Leer.mostrarEnPantalla(i+".- " + ((Libro)comentarios[i]).getTitulo());
		}
			else if (comentarios[i] != null && !(comentarios[i] instanceof Libro)) {
				Leer.mostrarEnPantalla("no has introducido un id de libro correcto");
			}
	}
}

	private static Integer menu() {
		Integer opcion;
		Leer.mostrarEnPantalla("\n1- Crear autor.\n2- Crear libro.\n3- Modificar autor.\n" + "4- Modificar libro.\n" + "5- Listado de autores.\n"
			+ "6- Listado de libros.\n" + "7- Comentar Libros y autores.\n"+"8- Ordenar Vector\n"+"0- Salir.");
		opcion = Leer.pedirEntero("\nElija opcion","[0-8]");
		return opcion;
	}//menu y opci�n

	private static Autor[] ampliaAutores(Autor[] autores, Integer posAutor) {
		if(posAutor>0.8*autores.length){
			autores=Arrays.copyOf(autores, autores.length+10);
		}
		return autores;
	}// ampl�a el vector de autores cuando se supera el 80%

	private static Libro[] ampliaLibros(Libro[] libros, Integer posLibro) {
		if(posLibro>0.8*libros.length){
			libros=Arrays.copyOf(libros, libros.length+10);
		}
		return libros;
	}// ampl�a el vector de libros cuando se supera el 80%

	private static Integer creaAutor(Autor[] autores, Integer posAutor){
		Autor autor;
		String nombreAutor, email, sexo;
		Character letraSexo;
		Integer indiceAutor;
		// Comprobar si el autor ya est� en el vector
		nombreAutor = Leer.pedirCadena("Nombre del autor?");
		indiceAutor = buscarAutor(autores, nombreAutor);// devuelve la posicion del nombre o -1 si no est�
		if (indiceAutor == -1) {
			// creamos el autor y lo guardamos en el vector
			email = Leer.pedirCadena("Email autor?","^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
			sexo = Leer.pedirCadena("Genero autor: (m)asculino (f)emenino ?","^[mMfF]$");
			letraSexo = sexo.charAt(0);
			autor = new Autor(nombreAutor, email, letraSexo);
			autores[posAutor] = autor;
			posAutor++;
			Leer.mostrarEnPantalla("Autor creado correctamente");
		} else {// el autor ya existe
			Leer.mostrarEnPantalla("El autor ya existe");
		}
		return posAutor;
	}//crear autor

	public static Integer crearLibros(Integer posLibros, Libro[] libros, Autor[] autores) {
		int indiceAutor, indiceTitulo;
		String titulo, nombreAutor;
		Autor autor;
		Double precio;
		Integer cantidad;
		// Comprobar si el libro ya esta en el vector 
		titulo = Leer.pedirCadena("Titulo del libro?");
		indiceTitulo = buscarTitulo(libros, titulo);
		while (indiceTitulo != -1) {
			titulo = Leer.pedirCadena("El libro ya existe y no se puede repetir. Titulo del libro?");
			indiceTitulo = buscarTitulo(libros, titulo);
		}
		// Comprobar si el autor ya esta en el vector
		nombreAutor = Leer.pedirCadena("Nombre del autor?");
		indiceAutor = buscarAutor(autores, nombreAutor);// devuelve la posicion del nombre o -1 si no lo encuentra
		if (indiceAutor == -1) {
			Leer.mostrarEnPantalla("El autor no existe");
		} else {// se crea el libro con ese autor
			autor = autores[indiceAutor];
			//pedir el resto de los datos del libro
			precio = Leer.pedirDouble("Precio del libro?","^\\d+[.][0-9]?[0-9]?$");//decimal con un m�ximo de dos posiciones decimales
			cantidad = Leer.pedirEntero("Cantidad de libros?","^\\d+$");//entero positivo
			libros[posLibros] = new Libro(titulo, autor, precio, cantidad);
			posLibros++;
			Leer.mostrarEnPantalla("Libro creado correctamente");
		}
		return posLibros;
	}// crear un Libro

	
	public static Integer creaAutores(Autor []autores,Integer posAutor,Integer numComent, Comentable comentarios[]){
		// creamos 3 autores
		autores[0]= new Autor("Rosa Montero", "rmontero@gmail.com", 'f');
		comentarios[Autor.getSiguiente()+Libro.getContador()-1]= autores[0];
		numComent++;
		autores[1]= new Autor("Juan Jose Millas", "jjmillas@hotmail.es",'m');
		comentarios[Autor.getSiguiente()+Libro.getContador()-1]= autores[1];
		numComent++;
		autores[2]= new Autor("Almudena Grandes", "ag@gmail.com",'f');
		comentarios[Autor.getSiguiente()+Libro.getContador()-1]= autores[2];
		numComent++;
		return 3;
	}// crea 3 autores
	
	public static Integer creaLibros(Autor[] autores, Integer posLibro, Libro[] libros,Integer numComent,Comentable comentarios[]){
		// creamos 5 libros
		libros[0]= new Libro("L�grimas en la lluvia", autores[0],19.95 ,100000);
		comentarios[Autor.getSiguiente()+Libro.getContador()-2]= libros[0];
		numComent++;
		libros[1]= new Libro("La rid�cula idea de no volver a verte", autores[0], 15., 200000);
		comentarios[Autor.getSiguiente()+Libro.getContador()-2]= libros[1];
		numComent++;
		libros[2]= new Libro("Desde la sombra", autores[1], 25., 75000);
		comentarios[Autor.getSiguiente()+Libro.getContador()-2]= libros[2];
		numComent++;
		libros[3]= new Libro("Malena es un nombre de tango", autores[2], 22., 100000);
		comentarios[Autor.getSiguiente()+Libro.getContador()-2]= libros[3];
		numComent++;
		libros[4]= new Libro("Las edades de Lul�", autores[2], 30., 200000);
		comentarios[Autor.getSiguiente()+Libro.getContador()-2]= libros[4];
		numComent++;
		 return 5;
	}// crea 5 libros

	public static int buscarAutor(Autor[] autores, String nombre) {
		// devuelve la posicion del nombre o -1 si no lo encuentra
		int indiceAutor=-1, i=0;
		while (autores[i] != null && i < autores.length && indiceAutor==-1) {
			if (autores[i].getNombre().equals(nombre)) {
				indiceAutor = i;
			}
			i++;
		}
		return indiceAutor;
	}//buscar autor

	public static int buscarTitulo(Libro[] libros, String titulo) {
		// devuelve el indice de la posici�n donde est� ese t�tulo o el valor -1 si no lo encuentra
		int i = 0, indiceLibro = -1;
		while ( libros[i] != null && i < libros.length && indiceLibro==-1) {
			if (libros[i].getTitulo().equals(titulo)) {
				indiceLibro = i;
			}
			i++;
		}
		return indiceLibro;
	}//buscar libro
	
	public static void listarAutores(Autor[] autores) {
		int indiceAutor;
		Leer.mostrarEnPantalla("\nListado de autores");
		Leer.mostrarEnPantalla("-------------------");
		for (indiceAutor = 0; indiceAutor < autores.length && autores[indiceAutor] != null; indiceAutor++) {
			Leer.mostrarEnPantalla("\n" + autores[indiceAutor].cadenaAutor());
		}
		Leer.mostrarEnPantalla("------------------------------------------------------------------");
	}//listarAutores

	public static void listarLibros(Libro[] libros) {
		int indiceLibro;
		Leer.mostrarEnPantalla("\nListado de libros");
		Leer.mostrarEnPantalla("------------------");
		for (indiceLibro = 0; indiceLibro < libros.length && libros[indiceLibro] != null; indiceLibro++) {
			Leer.mostrarEnPantalla("\n" + libros[indiceLibro].cadenaLibro());
		}
		Leer.mostrarEnPantalla("------------------------------------------------------------------");
	}//listarLibros

	public static void modificarAutor(Autor [] autores, String nombre){
		Integer indiceAutor, indice2;
		String email, sexo;
		Autor autor;
		
		//posicion del autor o -1 si no est�
		indiceAutor = buscarAutor(autores, nombre);
		if(indiceAutor != -1){
			autor=autores[indiceAutor];
			nombre = Leer.pedirCadena("Nuevo nombre (* no cambiar)");
			if(!nombre.equals("*")){
				indice2 = buscarAutor(autores, nombre);//verificamos que el nuevo nombre no est� repetido
				if(indice2!= -1){//nombre ya existente
					Leer.mostrarEnPantalla("El nuevo nombre ya est� en la lista, posici�n "+indice2+" No se puede cambiar");
				}else{//nombre nuevo
					autor.setNombre(nombre);	
				}
			}
			email = Leer.pedirCadena("Nuevo email (* no cambiar)","^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$|[*]");
			if(!email.equals("*")){
				autor.setEmail(email);
			}
			sexo=Leer.pedirCadena("Nuevo sexo ","[mMfF]");
			autor.setSexo(sexo.charAt(0));
		}else{
			Leer.mostrarEnPantalla("Error. El autor " + nombre + " no existe");
		}
	}//modificarAutor

	public static void modificarLibro(Libro [] libros, String titulo, Autor [] autores){
		Integer indiceAutor, indice2, indiceLibro;
		Autor autor;
		Libro libro;
		Double precio;
		Integer cantidad;
		String nombre;
		
		//posicion del libro, -1 si no lo encuentra
		indiceLibro = buscarTitulo(libros, titulo); 
		if(indiceLibro != -1){
			libro=libros[indiceLibro];
			titulo = Leer.pedirCadena("Nuevo t�tulo (* no cambiar)");
			if(!titulo.equals("*")){//si no se teclea * se mantiene el t�tulo
				indice2 = buscarTitulo(libros, titulo);//verificamos que el nuevo t�tulo no est� repetido
				if(indice2!= -1){//el t�tulo ya existe (puede ser el mismo)
					Leer.mostrarEnPantalla("El nuevo t�tulo ya est� en la lista, posici�n "+indice2+" No se puede cambiar");
				}else{//el nuevo t�tulo es nuevo de verdad
					libro.setTitulo(titulo);	
				}
			}
			precio = Leer.pedirDouble("Precio "+libro.getPrecio()+" Nuevo precio del libro ","^\\d+[.][0-9]?[0-9]?$");
			libro.setPrecio(precio);
			cantidad = Leer.pedirEntero("Cantidad " +libro.getCantidad()+" Nueva cantidad de libros ","^\\d+$");
			libro.setCantidad(cantidad);
			autor=libro.getAutor();
			nombre=Leer.pedirCadena("Nombre del nuevo autor (* mantener el actual)");
			if(!nombre.equals("*")){// se ha dado un nuevo nombre de autor
				indice2=buscarAutor(autores,nombre);
				if (indice2==-1){//autor no encontrado
					Leer.mostrarEnPantalla("Ese autor no est� en la lista. No se puede cambiar");
				} else {//nuevo autor encontrado
					libro.setAutor(autores[indice2]);
				}
			}
		}else{
			Leer.mostrarEnPantalla("Error. El libro " + titulo + " no existe");
		}		
	}//modificarLibro
}// class 
