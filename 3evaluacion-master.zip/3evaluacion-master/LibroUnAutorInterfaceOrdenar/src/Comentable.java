
public interface Comentable {
	void comentar(String texto);
	String comentario();
}
